# Ujala Chauraiya — Developer Portfolio

A responsive portfolio made with plain HTML, CSS and JavaScript. No build tools or installation required.

## Run it
1. Extract `Ujala_Portfolio.zip`.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Optional: in VS Code, use the Live Server extension for a local preview.

## Customize
- Update text, project descriptions and links in `index.html`.
- Adjust colors and spacing in `style.css` (look at the `:root` variables near the top).
- Interactions and reveal animations are in `script.js`.

## Before publishing
- Add real GitHub repository links to each project when available.
- Replace project summaries with the exact features and technologies you built.
- Add a resume PDF link if you want to share your resume.
- Google Fonts are loaded online; system fonts will be used if offline.
- The email contact link opens the visitor's email application; it is not a backend contact form.

Built for Ujala Chauraiya · B.Tech Information Technology · Lucknow
